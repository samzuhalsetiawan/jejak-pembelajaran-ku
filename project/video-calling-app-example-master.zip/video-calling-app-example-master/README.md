# video-calling-app-example

To run the example:

`yarn && yarn dev`
 
 or if you use npm:
 
 `npm i && npm run dev`
 
 Once the server is running, open http://localhost:3000 in 2 separate tabs in your favourite browser.
 
 Select ID of the user and click call.
