Hallo Kak,
Nama saya Sam Zuhal Setiawan
Email saya samzuhal095@gmail.com

nama aplikasi: Bahasa Pemrograman by Sam Zuhal Setiawan

berikut hasil submission yang telah saya kerjakan.
Saya menerapkan hal-hal yang telah saya pelajari dari kelas "Belajar Membuat Aplikasi Android untuk Pemula" ini
walau ada beberapa materi yang masih kurang paham namun pengetahuan saja akan dunia android sudah jauh lebih
baik daripada sebelum mengikuti kelas ini.
semoga submission saya ini memenuhi kriteria yang kakak tetapkan, mohon maaf jikalau UI nya aga masih terlalu umum.
Kedepannya saya akan memperdalam ilmu layouting saya dan tentunya logic kotlinnya juga.
Saya telah mencoba sejauh saya bisa. Semoga diterima amin :)