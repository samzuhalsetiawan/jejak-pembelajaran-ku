## a129-jetpack-lab
Repository ini berisi kode hasil dari codelab yang ada di **Semua modul di kelas Belajar Membuat Aplikasi Android untuk Pemula**.
Di dalamnya terdapat materi:
* Introduction
* Activity
* Intent
* Views and ViewGroup
* Style and Theme
* RecyclerView

Mulailah karirmu sebagai Android Developer dari sini. Materi disusun oleh **Dicoding sebagai Google Authorized Training Partner**.
Ikuti kelas [Belajar Membuat Aplikasi Android untuk Pemula](https://www.dicoding.com/academies/51/) di Dicoding Indonesia
