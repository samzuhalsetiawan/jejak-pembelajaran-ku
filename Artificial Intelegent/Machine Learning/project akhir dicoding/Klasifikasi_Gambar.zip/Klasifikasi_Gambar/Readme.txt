Hallo Kak,
Nama saya Sam Zuhal Setiawan
Email saya samzuhal095@gmail.com

berikut hasil submission yang telah saya kerjakan.
Saya menerapkan hal-hal yang telah saya pelajari dari kelas machine learning ini
walau ada beberapa materi yang masih kurang paham namun pengetahuan saja akan machine learning sudah jauh lebih
baik daripada sebelum mengikuti kelas ini.
semoga submission saya ini memenuhi kriteria yang kakak tetapkan, mohon maaf jikalau submission ini kurang memenuhi kriteria.
Saya telah mencoba sejauh saya bisa. Semoga diterima amin :)